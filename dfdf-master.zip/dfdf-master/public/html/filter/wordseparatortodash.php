<form id="wordseparatortodash">	

	<div class="form-group col-md-6">
		<label for="min">Separator:</label>
		<input type="text" id="wordseparatortodash-separator" name="my_element[filterOption][wordseparatortodash][separator]" class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            