<form id="boolean">	
	<div class="form-group col-md-6">
		<label for="min">Translations:</label>
		<input type="text" id="boolean-translations" name="my_element[filterOption][boolean][translations]" placeholder="a1,a2,a3..." class="form-control" />
	</div>

	<div class="form-group col-md-12">
		Casting:
		<input type="checkbox" id="boolean-casting" name="my_element[filterOption][boolean][casting]" />
	</div>

	<div class="form-group col-md-12">
		<label for="min">Type:</label>
		<input type="number" id="boolean-type" name="my_element[filterOption][boolean][type]"  class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            