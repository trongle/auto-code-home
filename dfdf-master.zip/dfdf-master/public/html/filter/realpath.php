<form id="realpath">	

	<div class="form-group col-md-6">
		Exists:
		<input type="checkbox" name="my_element[filterOption][realpath][exists]"/>
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            