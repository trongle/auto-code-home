<form id="htmlentities">	
	<div class="form-group col-md-6">
		<label for="min">Quotestyle:</label>
		<input type="text" id="htmlentities-quotestyle" name="my_element[filterOption][htmlentities][quotestyle]"  class="form-control" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Charset:</label>
		<input type="text" id="htmlentities-charset" name="my_element[filterOption][htmlentities][charset]" class="form-control" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Double Quote:</label>
		<input type="text" id="htmlentities-doublequote" name="my_element[filterOption][htmlentities][doublequote]" class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            