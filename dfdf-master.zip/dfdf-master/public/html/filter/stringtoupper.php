<form id="stringtoupper">	

	<div class="form-group col-md-6">
		<label for="min">Encoding:</label>
		<input type="text" id="stringtoupper-encoding" name="my_element[filterOption][stringtoupper][encoding]"  class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            