<form id="tonull">	

	<div class="form-group col-md-6">
		<label for="min">Type:</label>
		<input type="text" id="tonull-type" name="my_element[filterOption][tonull][type]"  class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            