<form id="alpha">	
	
	<div class="form-group col-md-6">
		<label for="adapter">Locale:</label>
		<input type="text" id="alpha-locale" name="my_element[filterOption][alpha][locale]" class="form-control" />
	</div>

	<div class="form-group col-md-12">
		Allow white space: <input type="checkbox" id="alpha-allow_white_space" name="my_element[filterOption][alpha][allow_white_space]"   />
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            