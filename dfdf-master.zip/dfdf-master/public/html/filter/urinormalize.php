<form id="urinormalize">	

	<div class="form-group col-md-6">
		<label for="min">Default Scheme:</label>
		<input type="text" id="urinormalize-defaultScheme" name="my_element[filterOption][urinormalize][defaultScheme]"  class="form-control" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Enforced Scheme:</label>
		<input type="text" id="urinormalize-enforcedScheme" name="my_element[filterOption][urinormalize][enforcedScheme]"  class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            