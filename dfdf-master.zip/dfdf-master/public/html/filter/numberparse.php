<form id="numberparse">	

	<div class="form-group col-md-6">
		<label for="min">Locale:</label>
		<input type="text" name="my_element[filterOption][numberparse][locale]"  class="form-control" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Style:</label>
		<input type="text" name="my_element[filterOption][numberparse][style]"  class="form-control" />
	</div>

	<div class="form-group col-md-6">
		<label for="min">Type:</label>
		<input type="text" name="my_element[filterOption][numberformat][type]"  class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>   
                            