<form id="lessthan">
	<div class="form-group col-md-6">
		<label>Max:</label>
		<input type="number" id="lessthan-max"  name="my_element[validateOption][lessthan][max]"/>
	</div>

	<div class="form-group col-md-12">
		Inclusive: <input type="checkbox" id="lessthan-inclusive" name="my_element[validateOption][lessthan][inclusive]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
