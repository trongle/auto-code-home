<form id="uri">
	<div class="form-group col-md-12">
		allow relative :
		<input type="checkbox" id="uri-allowrelatie" name="my_element[validateOption][uri][allowrelative]" />
	</div> 

	<div class="form-group col-md-12">
		allow absolute :
		<input type="checkbox" id="uri-allowabsolute" name="my_element[validateOption][uri][allowabsolute]" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>