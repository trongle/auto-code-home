<form id="uri">
	<div class="form-group col-md-12">
		allow relative :
		<input type="checkbox" name="my_element[validateOption][uri][allowrelatie]" />
	</div> 

	<div class="form-group col-md-12">
		allow absolute :
		<input type="checkbox" name="my_element[validateOption][uri][allowabsolute]" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>