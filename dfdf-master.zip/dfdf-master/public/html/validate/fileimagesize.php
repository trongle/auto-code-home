<form id="fileimagesize" >
	<div class="form-group col-md-6">
		<label>Min width:</label>
		<input type="number" name="my_element[validateOption][fileimagesize][minwidth]" class="form-control"/>
	</div>  

	<div class="form-group col-md-6">
		<label>Max width:</label>
		<input type="number"  name="my_element[validateOption][fileimagesize][maxwidth]" class="form-control"/>
	</div>

	<div class="form-group col-md-6">
		<label>Min height:</label>
		<input type="number" name="my_element[validateOption][fileimagesize][minheight]" class="form-control"/>
	</div>

	<div class="form-group col-md-6">
		<label>Max height:</label>
		<input type="number" name="my_element[validateOption][fileimagesize][maxheight]" class="form-control"/>
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>