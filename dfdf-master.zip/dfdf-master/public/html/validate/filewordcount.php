<form id="filewordcount">
	<div class="form-group col-md-6">
		<label>min:</label>
		<input type="number" id="filewordcount-min" name="my_element[validateOption][filewordcount][min]" class="form-control" />
	</div>  

	<div class="form-group col-md-6">
		<label>max:</label>
		<input type="number" id="filewordcount-max" name="my_element[validateOption][filewordcount][max]" class="form-control"/>
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>