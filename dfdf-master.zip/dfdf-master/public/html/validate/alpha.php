<form id="alpha">
	<div class="form-group col-md-6">
		Allow white space:
		<input type="checkbox" id="alpha-allowWhiteSpace" name="my_element[validateOption][alpha][allowWhiteSpace]"  />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
                            