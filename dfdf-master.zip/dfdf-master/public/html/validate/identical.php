<form id="identical" >	
	          
	<div class="form-group col-md-6">
		<label for="length">Token:</label>
		<input type="text" name="my_element[validateOption][identical][token]" class="form-control" />
	</div>
	
	<div class="form-group col-md-12">
		Strict: <input type="checkbox" name="my_element[validateOption][identical][strict]" />
	</div>

	<div class="form-group col-md-12">
		Literal: <input type="checkbox" name="my_element[validateOption][identical][literal]" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form> 