<form id="isintanseof" >

	<div class="form-group col-md-6">
		<label>Class name:</label>
		<input type="text" name="my_element[validateOption][isintanseof][classname]" class="form-control" />
	</div> 

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>