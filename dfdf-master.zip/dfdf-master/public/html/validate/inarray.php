<form id="inarray">
	
	<div class="form-group col-md-6">
		<label>Strict:</label> 
		<input type="number" class="form-control" name="my_element[validateOption][inarray][strict]" />
	</div>

	<div class="form-group col-md-6">
		<label>haystack:</label> 
		<input type="text" name="my_element[validateOption][inarray][haystack]" class="form-control" />
	</div>

	<div class="form-group col-md-12">
		Recursive: <input type="checkbox" name="my_element[validateOption][inarray][recursive]" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div>

</form> 