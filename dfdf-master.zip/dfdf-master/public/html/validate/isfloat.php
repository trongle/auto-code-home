<form id="isfloat">
	<div class="form-group col-md-6">
		<label>Locale:</label>
		<input type="text" name="my_element[validateOption][isfloat][locale]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
