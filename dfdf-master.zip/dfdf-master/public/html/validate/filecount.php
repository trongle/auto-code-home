<form id="filecount" >

	<div class="form-group col-md-6">
		<label>Min:</label>
		<input type="number" name="my_element[validateOption][filecount][min]" class="form-control"/>
	</div>

	<div class="form-group col-md-6">
		<label>Max:</label>
		<input type="number" class="form-control" name="my_element[validateOption][filecount][max]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
