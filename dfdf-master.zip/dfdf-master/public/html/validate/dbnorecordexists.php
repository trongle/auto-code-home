<form id="dbnorecordexists" >
	<div class="form-group col-md-6">
		<label for="min">Table:</label>
		<input type="text" name="my_element[validateOption][dbnorecordexists][table]" class="form-control" />
	</div>
	    
	<div class="form-group col-md-6">
		<label for="min">Field:</label>
		<input type="text" name="my_element[validateOption][dbnorecordexists][field]" class="form-control" />
	</div> 

	<div class="form-group col-md-6">
		<label for="min">Adapter:</label>
		<input type="text" name="my_element[validateOption][dbnorecordexists][adapter]" class="form-control" />
	</div>  

	<div class="form-group col-md-6">
		<label for="min">Exclude:</label>
		<input name="my_element[validateOption][dbnorecordexists][exclude]" class="form-control" placeholder="field:name,value:name"/>
	</div>

	<div class="form-group col-md-6">
		<label for="min">Schema:</label>
		<input name="my_element[validateOption][dbnorecordexists][schema]" class="form-control" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
