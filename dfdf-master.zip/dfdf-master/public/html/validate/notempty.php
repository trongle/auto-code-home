<form id="notempty">

	<div class="form-group col-md-6">
		<label>Type:</label>
		<input type="text" id="notempty-type" name="my_element[validateOption][notempty][type]"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>
