<form id="regex">
	<div class="form-group col-md-6">
		<label>pattern :</label>
		<input type="text" id="regex-pattern" name="my_element[validateOption][regex][pattern]" class="form-control" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>