<form id="filemd5">

	<div class="form-group col-md-6">
		<label>Hash:</label>
		<input type="text" name="my_element[validateOption][filemd5][hash]" class="form-control"/>
	</div>
	
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>