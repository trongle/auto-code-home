<form id="filehash" >
	<div class="form-group col-md-6">
		<label>Algorithm:</label>
		<input type="text" id="filehash-algorithm" name="my_element[validateOption][filehash][algorithm]" class="form-control"/>
	</div>  

	<div class="form-group col-md-6">
		<label>Hash:</label>
		<input type="text" id="filehash-hash" name="my_element[validateOption][filehash][hash]" class="form-control"/>
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>