<form id="filecrc32" >
	<div class="form-group col-md-6">
		<label>Hash:</label>
		<input type="text" name="my_element[validateOption][filecrc32][hash]"/>
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>