<form id="isbn" >
	<div class="form-group col-md-6">
		<label>type:</label>
		<input type="text" name="my_element[validateOption][isbn][type]" class="form-control" />
	</div> 

	<div class="form-group col-md-6">
		<label>separator :</label>
		<input type="text" name="my_element[validateOption][isbn][separator]" class="form-control" />
	</div>
	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>