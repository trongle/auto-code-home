<form id="stringlength">                    
	<div class="form-group col-md-6">
		<label for="min">min:</label>
		<input type="number" name="my_element[validateOption][stringlength][min]" class="form-control" />
	</div>
	    
	<div class="form-group col-md-6">
		<label for="min">max:</label>
		<input type="number" name="my_element[validateOption][stringlength][max]" class="form-control" />
	</div>

	<div class="form-group col-md-12">	   
    	<button class="btn btn-primary accept" >Accept</button>
    	<button class="btn btn-info cancel" >Cancel</button>		        			    
    </div> 
</form>      

